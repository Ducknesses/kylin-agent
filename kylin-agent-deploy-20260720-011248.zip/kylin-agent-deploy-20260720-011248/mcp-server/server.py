"""MCP Server 主入口：HTTP JSON-RPC 2.0 服务"""
import hmac
import json
import logging
import logging.handlers
import os
import signal
import sys
import threading
import time
import traceback
from http.server import HTTPServer, BaseHTTPRequestHandler

# 确保能找到同目录模块
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import config
from plugins import sys_info, service_mgr, log_reader, net_monitor, cmd_exec, file_guard
from plugins import mcp_self_monitor, metrics_store

# ============================================================
# 工具注册表
# ============================================================
TOOLS = {
    "sys_info": sys_info.handle,
    "service_mgr": service_mgr.handle,
    "log_reader": log_reader.handle,
    "net_monitor": net_monitor.handle,
    "cmd_exec": cmd_exec.handle,
    "file_guard": file_guard.handle,
    "mcp_self_monitor": mcp_self_monitor.handle,
    "metrics_history": metrics_store.handle,
}

# ============================================================
# Pending Confirmation 存储
# ============================================================
PENDING_STORE: dict[str, dict] = {}   # confirm_id -> {tool_name, arguments, created_at, ...}
PENDING_LOCK = threading.Lock()
PENDING_TIMEOUT = 120  # 秒，超时自动拒绝

# JSON-RPC 2.0 标准错误码
JSONRPC_ERRORS = {
    "PARSE_ERROR": (-32700, "解析错误"),
    "INVALID_REQUEST": (-32600, "无效请求"),
    "METHOD_NOT_FOUND": (-32601, "未知工具名"),
    "INVALID_PARAMS": (-32602, "参数错误"),
    "INTERNAL_ERROR": (-32603, "内部错误"),
    "COMMAND_BLOCKED": (-32600, "命令被安全策略拦截"),
    "EXECUTION_FAILED": (-32000, "命令执行失败"),
    "PENDING_EXPIRED": (-32002, "待确认操作已过期"),
    "PENDING_NOT_FOUND": (-32003, "待确认操作不存在"),
}


def setup_logging():
    """
    配置日志。
    systemd 环境（INVOCATION_ID 存在）：仅 stdout，由 journald 捕获
    非 systemd 环境：RotatingFileHandler + stdout 双输出
    """
    in_systemd = bool(os.environ.get("INVOCATION_ID"))

    log_format = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)

    if in_systemd:
        # systemd 模式：仅输出到 stdout，由 journald 自动捕获
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(log_format)
        console_handler.setLevel(getattr(logging, config.LOG_LEVEL.upper(), logging.INFO))
        root_logger.addHandler(console_handler)
        return root_logger

    # ---- 非 systemd 模式：文件 + 控制台 ----

    # 文件日志（带轮转，每个文件10MB保留3个）
    log_dir = os.path.dirname(config.LOG_FILE)
    if log_dir and not os.path.exists(log_dir):
        os.makedirs(log_dir, exist_ok=True)

    try:
        file_handler = logging.handlers.RotatingFileHandler(
            config.LOG_FILE,
            maxBytes=10 * 1024 * 1024,
            backupCount=3,
            encoding="utf-8",
        )
        file_handler.setFormatter(log_format)
        file_handler.setLevel(getattr(logging, config.LOG_LEVEL.upper(), logging.INFO))
        root_logger.addHandler(file_handler)
    except PermissionError:
        # 无权写入 /var/log 时回退到当前目录
        fallback_log = os.path.join(os.path.dirname(__file__), "mcp-server.log")
        print(f"[WARN] 无法写入 {config.LOG_FILE}，日志回退到 {fallback_log}")
        try:
            fallback_handler = logging.handlers.RotatingFileHandler(
                fallback_log,
                maxBytes=10 * 1024 * 1024,
                backupCount=3,
                encoding="utf-8",
            )
            fallback_handler.setFormatter(log_format)
            fallback_handler.setLevel(getattr(logging, config.LOG_LEVEL.upper(), logging.INFO))
            root_logger.addHandler(fallback_handler)
        except Exception:
            # 连当前目录也写不了，只用控制台
            pass

    # 控制台日志（非 systemd 模式同样输出一份到控制台）
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(log_format)
    console_handler.setLevel(getattr(logging, config.LOG_LEVEL.upper(), logging.INFO))
    root_logger.addHandler(console_handler)

    return root_logger


def make_jsonrpc_error(code: int, message: str, req_id=None, extra: dict = None) -> dict:
    """构造 JSON-RPC 2.0 错误响应"""
    error = {"code": code, "message": message}
    if extra:
        error["data"] = extra
    return {"jsonrpc": "2.0", "error": error, "id": req_id}


def make_jsonrpc_response(result, req_id=None) -> dict:
    """构造 JSON-RPC 2.0 成功响应"""
    return {"jsonrpc": "2.0", "result": result, "id": req_id}


def cleanup_expired_pending():
    """清理过期的待确认操作"""
    now = time.time()
    with PENDING_LOCK:
        expired = [cid for cid, v in PENDING_STORE.items() if now - v.get("created_at", 0) > PENDING_TIMEOUT]
        for cid in expired:
            logger.info("[Pending] 清理过期待确认: confirm_id=%s, tool=%s", cid, PENDING_STORE[cid].get("tool_name"))
            del PENDING_STORE[cid]


def handle_pending_confirm(params: dict, req_id=None) -> dict:
    """
    处理 tools/pending_confirm 请求

    params: {
        "confirm_id": "xxx",      # 待确认ID
        "approved": true/false    # 是否批准
    }
    """
    confirm_id = params.get("confirm_id", "").strip()
    approved = params.get("approved", False)

    if not confirm_id:
        return make_jsonrpc_error(*JSONRPC_ERRORS["INVALID_PARAMS"], req_id,
                                  extra={"detail": "缺少参数: confirm_id"})

    with PENDING_LOCK:
        pending = PENDING_STORE.get(confirm_id)

    if pending is None:
        return make_jsonrpc_error(*JSONRPC_ERRORS["PENDING_NOT_FOUND"], req_id,
                                  extra={"detail": f"待确认操作不存在或已过期: {confirm_id}"})

    # 检查超时
    if time.time() - pending.get("created_at", 0) > PENDING_TIMEOUT:
        with PENDING_LOCK:
            PENDING_STORE.pop(confirm_id, None)
        return make_jsonrpc_error(*JSONRPC_ERRORS["PENDING_EXPIRED"], req_id,
                                  extra={"detail": f"待确认操作已过期: {confirm_id}"})

    if not approved:
        # 用户拒绝 → 从存储移除，返回拒绝状态
        with PENDING_LOCK:
            PENDING_STORE.pop(confirm_id, None)
        logger.info("[Pending] 用户拒绝操作: confirm_id=%s, tool=%s", confirm_id, pending.get("tool_name"))
        mcp_self_monitor.request_stats["success"] += 1
        return make_jsonrpc_response({
            "status": "rejected",
            "confirm_id": confirm_id,
            "tool": pending.get("tool_name"),
            "reason": "用户拒绝了此操作",
        }, req_id)

    # 用户批准 → 实际执行工具调用
    tool_name = pending.get("tool_name", "")
    arguments = pending.get("arguments", {})

    with PENDING_LOCK:
        PENDING_STORE.pop(confirm_id, None)

    logger.info("[Pending] 用户批准执行: confirm_id=%s, tool=%s, args=%s", confirm_id, tool_name, arguments)

    # 调用工具处理函数
    try:
        result = TOOLS[tool_name](arguments)
        mcp_self_monitor.request_stats["success"] += 1
        # 包装结果，注明是经确认后执行的
        result["_confirmed"] = True
        result["_confirm_id"] = confirm_id
        return make_jsonrpc_response(result, req_id)
    except Exception as e:
        mcp_self_monitor.request_stats["errors"] += 1
        tb = traceback.format_exc()
        logger.error("[Pending] 确认后执行异常 tool=%s:\n%s", tool_name, tb)
        return make_jsonrpc_error(*JSONRPC_ERRORS["INTERNAL_ERROR"], req_id,
                                  extra={"detail": str(e), "tool": tool_name})


def handle_tools_list(req_id=None) -> dict:
    """列出所有可用工具及其参数定义"""
    tool_defs = {
        "sys_info": {
            "description": "获取系统信息（CPU、内存、磁盘、负载）",
            "parameters": {
                "metric": "cpu|memory|disk|load|uptime|all",
            },
        },
        "service_mgr": {
            "description": "管理系统服务",
            "parameters": {
                "action": "status|start|stop|restart",
                "service": "服务名称",
            },
        },
        "log_reader": {
            "description": "读取系统日志，支持关键词过滤",
            "parameters": {
                "type": "journalctl|file",
                "source": "日志来源（别名或路径）",
                "lines": "行数",
                "service": "服务名（journalctl模式）",
                "since": "时间范围",
                "keyword": "关键词过滤（可选）",
            },
        },
        "net_monitor": {
            "description": "网络监控信息（连接/流量/网卡/路由/DNS/监听端口）",
            "parameters": {
                "metric": "connections|traffic|interfaces|routes|dns|listen|all",
                "port": "端口号（listen模式筛选，可选）",
            },
        },
        "cmd_exec": {
            "description": "在沙箱中安全执行系统命令",
            "parameters": {
                "command": "要执行的命令",
                "timeout": "超时秒数（默认30）",
                "user": "执行用户（默认agent-read）",
            },
        },
        "file_guard": {
            "description": "文件安全检查、读取与安全写入（带审计日志）",
            "parameters": {
                "action": "check|read|write",
                "path": "文件路径",
                "content": "写入内容（write 操作）",
                "max_size": "最大读取字节数（默认1MB）",
            },
        },
        "metrics_history": {
            "description": "查询系统历史指标数据（CPU、内存、磁盘、网络），按时间范围返回历史读数",
            "parameters": {
                "from_ts": "开始时间戳（Unix秒，可选，默认5分钟前）",
                "to_ts": "结束时间戳（Unix秒，可选，默认当前时间）",
                "metrics": "逗号分隔的指标名: cpu,memory,disk,network,all（可选，默认all）",
                "limit": "最大返回条数（默认5000，最大10000）",
            },
        },
    }
    return make_jsonrpc_response({"tools": list(TOOLS.keys()), "definitions": tool_defs}, req_id)


def process_request(method: str, params: dict, req_id=None) -> dict:
    """
    处理单个 JSON-RPC 请求

    method: "tools/call" | "tools/list" | "tools/pending_confirm" | "ping"
    params: {"name": "sys_info", "arguments": {"metric": "cpu"}}  (tools/call)
    """
    # 定期清理过期待确认
    cleanup_expired_pending()

    # 请求统计
    mcp_self_monitor.request_stats["total"] += 1

    # 方法路由
    if method == "ping":
        mcp_self_monitor.request_stats["success"] += 1
        return make_jsonrpc_response({"pong": True, "version": "1.0.0", "tools_count": len(TOOLS)}, req_id)

    if method == "tools/list":
        mcp_self_monitor.request_stats["success"] += 1
        return handle_tools_list(req_id)

    if method == "tools/pending_confirm":
        return handle_pending_confirm(params, req_id)

    if method == "tools/call":
        tool_name = params.get("name", "")
        arguments = params.get("arguments", {})

        if not tool_name:
            mcp_self_monitor.request_stats["errors"] += 1
            return make_jsonrpc_error(*JSONRPC_ERRORS["INVALID_PARAMS"], req_id,
                                      extra={"detail": "缺少参数: name"})

        if tool_name not in TOOLS:
            mcp_self_monitor.request_stats["errors"] += 1
            return make_jsonrpc_error(*JSONRPC_ERRORS["METHOD_NOT_FOUND"], req_id,
                                      extra={"detail": f"未知工具: {tool_name}", "available": list(TOOLS.keys())})

        # 调用工具处理函数
        logger.info("[Server] 调用工具: %s, 参数: %s", tool_name, arguments)
        try:
            result = TOOLS[tool_name](arguments)

            # 检查插件是否返回了 pending_confirmation
            if isinstance(result, dict) and result.get("_pending_confirmation"):
                confirm_id = result.get("confirm_id", "")
                if confirm_id:
                    # 存入 PENDING_STORE 等待确认（使用插件返回的 pending_args，确保携带 _skip_pending 标记）
                    with PENDING_LOCK:
                        PENDING_STORE[confirm_id] = {
                            "tool_name": tool_name,
                            "arguments": result.get("pending_args", arguments),
                            "created_at": time.time(),
                        }
                    logger.info("[Pending] 操作需确认: tool=%s, confirm_id=%s, reason=%s",
                                tool_name, confirm_id, result.get("reason", ""))
                    mcp_self_monitor.request_stats["success"] += 1
                    return make_jsonrpc_response(result, req_id)

            mcp_self_monitor.request_stats["success"] += 1
            return make_jsonrpc_response(result, req_id)
        except Exception as e:
            mcp_self_monitor.request_stats["errors"] += 1
            tb = traceback.format_exc()
            logger.error("[Server] 工具 %s 执行异常:\n%s", tool_name, tb)
            return make_jsonrpc_error(*JSONRPC_ERRORS["INTERNAL_ERROR"], req_id,
                                      extra={"detail": str(e), "tool": tool_name})

    # 未知方法
    mcp_self_monitor.request_stats["errors"] += 1
    return make_jsonrpc_error(*JSONRPC_ERRORS["METHOD_NOT_FOUND"], req_id,
                              extra={"detail": f"未知方法: {method}"})


class MCPHandler(BaseHTTPRequestHandler):
    """HTTP 请求处理器"""

    # 禁止日志输出到标准错误（用logging替代）
    def log_message(self, format, *args):
        logger.debug("HTTP: %s", format % args)

    def _send_json(self, data: dict, status: int = 200):
        """发送 JSON 响应"""
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "http://localhost:5173")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        """处理 CORS 预检请求"""
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "http://localhost:5173")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()

    def _verify_token(self):
        """Bearer Token 认证：使用 hmac.compare_digest 防时序攻击"""
        auth = self.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return False
        token = auth[7:]
        return hmac.compare_digest(token, config.API_TOKEN)

    def do_GET(self):
        """GET 请求返回健康检查信息"""
        if self.path in ("/", "/health", "/ping"):
            self._send_json({
                "status": "ok",
                "service": "MCP Server for Kylin OS",
                "version": "1.0.0",
                "tools": len(TOOLS),
                "available_tools": list(TOOLS.keys()),
            })
        else:
            self._send_json({"error": "仅支持 POST 到 /mcp/v1/tools/ 接口"}, 404)

    def do_POST(self):
        """POST 请求处理 JSON-RPC 2.0 调用"""

        # Bearer Token 认证（所有 POST 请求强制校验）
        if not self._verify_token():
            self._send_json(
                make_jsonrpc_error(-32001, "未授权：Token 认证失败", None,
                                   extra={"detail": "请在 Authorization 头中提供有效的 Bearer Token"}),
                401,
            )
            return

        # 检查路径
        if self.path not in ("/mcp/v1/tools/call", "/mcp/v1/tools/list", "/mcp/v1/rpc", "/jsonrpc"):
            self._send_json(
                {"error": "未找到接口，请使用 /mcp/v1/tools/call"},
                404,
            )
            return

        # 读取请求体
        content_length = int(self.headers.get("Content-Length", 0))
        if content_length == 0:
            self._send_json(
                make_jsonrpc_error(*JSONRPC_ERRORS["INVALID_REQUEST"], None,
                                   extra={"detail": "请求体为空"}),
                400,
            )
            return

        if content_length > 10 * 1024 * 1024:  # 10MB上限
            self._send_json(
                make_jsonrpc_error(*JSONRPC_ERRORS["INVALID_REQUEST"], None,
                                   extra={"detail": "请求体过大"}),
                413,
            )
            return

        raw_body = self.rfile.read(content_length).decode("utf-8")

        # 解析 JSON
        try:
            request_data = json.loads(raw_body)
        except json.JSONDecodeError as e:
            logger.warning("[Server] JSON解析失败: %s", e)
            self._send_json(
                make_jsonrpc_error(*JSONRPC_ERRORS["PARSE_ERROR"], None,
                                   extra={"detail": str(e)}),
                400,
            )
            return

        # 验证 JSON-RPC 2.0 格式
        if not isinstance(request_data, dict):
            self._send_json(
                make_jsonrpc_error(*JSONRPC_ERRORS["INVALID_REQUEST"], None,
                                   extra={"detail": "请求必须是JSON对象"}),
                400,
            )
            return

        jsonrpc = request_data.get("jsonrpc", "")
        if jsonrpc != "2.0":
            self._send_json(
                make_jsonrpc_error(*JSONRPC_ERRORS["INVALID_REQUEST"], None,
                                   extra={"detail": "jsonrpc字段必须为'2.0'"}),
                400,
            )
            return

        method = request_data.get("method", "")
        params = request_data.get("params", {})
        req_id = request_data.get("id")

        if not method:
            self._send_json(
                make_jsonrpc_error(*JSONRPC_ERRORS["INVALID_REQUEST"], req_id,
                                   extra={"detail": "缺少method字段"}),
                400,
            )
            return

        # 处理请求
        logger.info(
            "[Server] 收到请求: id=%s, method=%s, params=%s",
            req_id, method, str(params)[:200],
        )

        response = process_request(method, params, req_id)

        # 如果是通知（无id），不返回响应
        if req_id is None:
            self._send_json({"jsonrpc": "2.0", "result": None}, 204)
            return

        self._send_json(response)


def create_server():
    """创建并配置 HTTP Server"""
    global server_instance
    server = HTTPServer((config.HOST, config.PORT), MCPHandler)

    # 设置超时
    server.timeout = 5
    server_instance = server

    return server


# ============================================================
# 模块级全局变量（供 mcp_self_monitor 插件访问）
# ============================================================
server_instance = None   # 当前 HTTPServer 实例
server_start_time = 0.0  # time.time() 启动时间戳

logger = None  # 模块级，setup_logging() 后设置


def restart_server(new_host=None, new_port=None):
    """热重启 HTTP Server，动态变更监听地址和端口

    在 Python HTTPServer（单线程阻塞）架构下，采用方式：
      1. 先创建新 socket 并绑定新地址（验证端口可用）
      2. 更新配置
      3. 将新 socket 塞入旧 server 实例（替换 server.socket）
      4. 旧 socket 关闭
      这样 serve_forever 继续运行，但使用新的 socket。

    替代方案（如果 socket 替换失败）：
      - 记录变更信息，下一次重启进程时生效
    """
    global server_instance

    old_host = config.HOST
    old_port = config.PORT

    target_host = new_host if new_host is not None else old_host
    target_port = new_port if new_port is not None else old_port

    logger.info(
        "[Server] 正在热重启 %s:%d -> %s:%d ...",
        old_host, old_port, target_host, target_port,
    )

    # 1. 创建新 socket 并绑定
    #    设置 SO_REUSEADDR + SO_REUSEPORT，允许新旧 socket 同时监听同一端口，
    #    从而避免"先关旧 socket 再绑新 socket"导致的服务中断窗口。
    import socket
    new_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    new_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        new_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
    except (AttributeError, OSError):
        pass  # 非 Linux 平台（macOS/Windows）不支持 SO_REUSEPORT，静默忽略

    try:
        new_sock.bind((target_host, target_port))
        new_sock.listen(5)
    except OSError as e:
        if old_host == target_host and old_port == target_port:
            new_sock.close()
            logger.error("[Server] 目标地址与当前相同，无需变更: %s:%d", target_host, target_port)
            return {
                "error": f"目标地址与当前相同: {target_host}:{target_port}",
                "current": {"host": old_host, "port": old_port},
            }
        if old_port == target_port:
            # SO_REUSEPORT 未能生效（非 Linux 平台降级路径）：
            # 必须先关闭旧 socket 释放端口，再绑定新 socket。
            # 为最小化服务中断，关闭与绑定之间不做 sleep。
            logger.warning(
                "[Server] 端口冲突 %s:%d，SO_REUSEPORT 不可用，关闭旧 socket 后重试绑定...",
                target_host, target_port,
            )
            try:
                old_sock = server_instance.socket
                old_sock.close()
                new_sock.bind((target_host, target_port))
                new_sock.listen(5)
            except OSError as e2:
                new_sock.close()
                logger.error("[Server] 重试绑定仍失败 %s:%d - %s", target_host, target_port, e2)
                # 恢复旧 socket 绑定（重新绑定旧端口）
                try:
                    restore_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    restore_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                    restore_sock.bind((old_host, old_port))
                    restore_sock.listen(5)
                    server_instance.socket = restore_sock
                    logger.info("[Server] 已恢复旧监听 %s:%d", old_host, old_port)
                except Exception as restore_err:
                    logger.critical(
                        "[Server] 无法恢复监听！旧地址 %s:%d，错误: %s",
                        old_host, old_port, restore_err,
                    )
                return {
                    "error": f"端口绑定失败: {e2}",
                    "current": {"host": old_host, "port": old_port},
                }
        else:
            new_sock.close()
            logger.error("[Server] 端口绑定失败 %s:%d - %s", target_host, target_port, e)
            return {
                "error": f"端口绑定失败: {e}",
                "current": {"host": old_host, "port": old_port},
            }

    # 2. 更新配置
    if new_host is not None:
        config.update_runtime("HOST", target_host)
    if new_port is not None:
        config.update_runtime("PORT", target_port)

    # 3. 替换 server 的 socket
    try:
        old_sock = server_instance.socket
        server_instance.socket = new_sock
        server_instance.server_address = (target_host, target_port)
    except Exception as e:
        new_sock.close()
        logger.exception("[Server] socket 替换失败: %s", e)
        return {
            "error": f"socket 替换失败: {e}",
            "current": {"host": old_host, "port": old_port},
        }

    # 安全关闭旧 socket（此时 new_sock 已生效，关闭旧 socket
    # 即使失败也不影响新 socket 正常工作）
    try:
        old_sock.close()
    except Exception:
        logger.warning("[Server] 关闭旧 socket 时出现异常（不影响新 socket）", exc_info=True)

    logger.info("[Server] socket 已替换: %s:%d -> %s:%d",
                 old_host, old_port, target_host, target_port)

    # 更新 mcp_self_monitor 中的 server_instance 引用
    mcp_self_monitor.server_instance = server_instance

    return {
        "success": True,
        "previous": {"host": old_host, "port": old_port},
        "current": {"host": target_host, "port": target_port},
        "message": f"监听地址已从 {old_host}:{old_port} 变更为 {target_host}:{target_port}",
    }


def main():
    """启动 MCP Server"""
    global logger, server_start_time
    logger = setup_logging()

    server_start_time = time.time()

    logger.info("=" * 60)
    logger.info("MCP Server for Kylin OS Agent 启动中...")
    logger.info("监听地址: %s:%d", config.HOST, config.PORT)
    logger.info("已注册工具 (%d): %s", len(TOOLS), list(TOOLS.keys()))
    logger.info("日志文件: %s", config.LOG_FILE)
    logger.info("=" * 60)

    server = create_server()

    _init_self_monitor()

    def shutdown_handler(signum, frame):
        logger.info("收到信号 %s，正在关闭服务器...", signum)
        server.shutdown()
        logger.info("MCP Server 已停止")

    signal.signal(signal.SIGTERM, shutdown_handler)
    signal.signal(signal.SIGINT, shutdown_handler)

    try:
        logger.info("MCP Server 已启动，等待请求...")
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    except Exception as e:
        logger.exception("服务器异常: %s", e)
        sys.exit(1)
    finally:
        server.server_close()
        logger.info("MCP Server 已关闭")


def _init_self_monitor():
    """初始化 mcp_self_monitor 插件的内部引用，以及 metrics_store 数据库和后台采集"""
    mcp_self_monitor.server_instance = server_instance
    mcp_self_monitor.server_start_time = server_start_time
    mcp_self_monitor.request_stats = {
        "total": 0,
        "success": 0,
        "errors": 0,
        "last_reset": time.time(),
    }
    mcp_self_monitor.restart_server_cb = restart_server

    # ── metrics_store 初始化 ──
    t0 = time.time()
    try:
        metrics_store.init_db()
        logger.info("[Server] metrics_store.init_db() 完成 (%.2fs)", time.time() - t0)

        metrics_store.cleanup_expired()
        logger.info("[Server] metrics_store.cleanup_expired() 完成 (%.2fs)", time.time() - t0)

        # VACUUM 改用后台线程延迟执行，避免启动时阻塞（大数据库可能耗时数秒）
        threading.Thread(
            target=_delayed_vacuum,
            daemon=True,
            name="metrics-vacuum",
        ).start()

        metrics_store.start_collect_thread()
        logger.info("[Server] 指标缓存初始化完成 (%.2fs)", time.time() - t0)
    except Exception as e:
        logger.exception("[Server] 指标缓存初始化失败: %s", e)


def _delayed_vacuum():
    """后台线程：延迟 5 秒后执行 VACUUM，避免阻塞服务启动"""
    time.sleep(5)
    try:
        metrics_store.vacuum_db()
    except Exception as e:
        logger.warning("[Server] 后台 VACUUM 失败: %s", e)


if __name__ == "__main__":
    main()