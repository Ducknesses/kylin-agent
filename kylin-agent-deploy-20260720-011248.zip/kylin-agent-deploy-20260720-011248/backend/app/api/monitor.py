"""监控数据接口

正式接口（最新前后端 API 统一规范 v1.0）：
  GET /api/monitor/metrics  → 嵌套结构 REST 快照（本地 psutil）（需要 READ 权限）
  GET /api/monitor/stream   → 扁平结构 SSE 实时流（本地 psutil）
  GET /api/monitor/history  → 历史指标数据（通过 MCP 拉取 SQLite 缓存）（需要 READ 权限）
"""
import asyncio
import json
import logging
import os
from datetime import datetime

import psutil
from fastapi import APIRouter, Depends, Query
from fastapi.responses import StreamingResponse

from app.core.auth import AuthContext, AuthLevel
from app.dependencies import require_auth
from app.mcp.client import MCPClient

logger = logging.getLogger(__name__)
router = APIRouter()

# 用于计算网络速率的上一轮采样值
_prev_net: dict = {"bytes_sent": 0, "bytes_recv": 0, "ts": 0.0}


def _collect_nested_metrics() -> dict:
    """采集系统指标 —— 嵌套结构，用于 /api/monitor/metrics"""
    cpu_pct = round(psutil.cpu_percent(interval=0.1), 1)
    mem = psutil.virtual_memory()
    disk = psutil.disk_usage("/")
    net = psutil.net_io_counters()

    total_gb = round(mem.total / (1024**3), 1)
    used_gb = round(mem.used / (1024**3), 1)
    disk_total_gb = round(disk.total / (1024**3), 1)
    disk_used_gb = round(disk.used / (1024**3), 1)

    global _prev_net
    now_ts = datetime.now().timestamp()
    rx_kbps, tx_kbps = 0.0, 0.0
    if _prev_net["ts"] > 0:
        elapsed = now_ts - _prev_net["ts"]
        if elapsed > 0:
            rx_delta = max(0, net.bytes_recv - _prev_net["bytes_recv"])
            tx_delta = max(0, net.bytes_sent - _prev_net["bytes_sent"])
            rx_kbps = round(rx_delta / elapsed / 1024, 1)
            tx_kbps = round(tx_delta / elapsed / 1024, 1)
    _prev_net = {"bytes_sent": net.bytes_sent, "bytes_recv": net.bytes_recv, "ts": now_ts}

    return {
        "cpu": {
            "percent": cpu_pct,
            "cores": psutil.cpu_count(logical=True),
        },
        "memory": {
            "percent": round(mem.percent, 1),
            "total_gb": total_gb,
            "used_gb": used_gb,
        },
        "disk": {
            "percent": round(disk.percent, 1),
            "total_gb": disk_total_gb,
            "used_gb": disk_used_gb,
        },
        "network": {
            "rx_kbps": rx_kbps,
            "tx_kbps": tx_kbps,
        },
        "timestamp": datetime.now().isoformat(),
    }


def _collect_flat_metrics() -> dict:
    """采集系统指标 —— 扁平结构，用于 /api/monitor/stream SSE"""
    nested = _collect_nested_metrics()
    try:
        load_avg = [round(v, 2) for v in os.getloadavg()]
    except (OSError, AttributeError):
        load_avg = [0.0, 0.0, 0.0]

    return {
        "cpu_percent": nested["cpu"]["percent"],
        "load_avg": load_avg,
        "memory_percent": nested["memory"]["percent"],
        "disk_percent": nested["disk"]["percent"],
        "net_in_kbps": nested["network"]["rx_kbps"],
        "net_out_kbps": nested["network"]["tx_kbps"],
        "timestamp": nested["timestamp"],
    }


async def _mcp_metrics_generator():
    """SSE 流式生成系统指标（通过 MCP 远程采集）

    每个事件均包含 mcp_connected 字段，前端可据此判断数据来源：
      - true  → MCP 连接正常，数据真实有效
      - false → MCP 连接失败，前端应标记为"已断开"并不再追加 0 值点
    """
    client = MCPClient()
    _prev_net_mcp = {"bytes_sent": 0, "bytes_recv": 0, "ts": 0.0}
    while True:
        try:
            mcp_ok = False
            try:
                result = await client.get_system_metrics()
                raw = result.get("result", {}) if result.get("ok") else {}
                mcp_ok = result.get("ok") and bool(raw)
            except Exception:
                raw = {}
                mcp_ok = False

            cpu_data = raw.get("cpu", {})
            mem_data = raw.get("memory", {})
            load_data = raw.get("load", {})

            disk_raw = raw.get("disk", {})
            if isinstance(disk_raw, list):
                disk_data = disk_raw[0] if disk_raw and isinstance(disk_raw[0], dict) else {}
            elif isinstance(disk_raw, dict):
                disk_data = disk_raw
            else:
                disk_data = {}

            disk_pct_str = disk_data.get("percent", "0")
            try:
                disk_pct = float(str(disk_pct_str).replace("%", "").strip())
            except (ValueError, TypeError):
                disk_pct = 0.0

            # 网络 IO：从 MCP 返回的原始计数器计算速率
            net_data = raw.get("network", {})
            net_in_kbps = 0.0
            net_out_kbps = 0.0
            if net_data:
                now_ts = datetime.now().timestamp()
                bytes_recv = net_data.get("bytes_recv", 0)
                bytes_sent = net_data.get("bytes_sent", 0)
                if _prev_net_mcp["ts"] > 0:
                    elapsed = now_ts - _prev_net_mcp["ts"]
                    if elapsed > 0:
                        rx_delta = max(0, bytes_recv - _prev_net_mcp["bytes_recv"])
                        tx_delta = max(0, bytes_sent - _prev_net_mcp["bytes_sent"])
                        net_in_kbps = round(rx_delta / elapsed / 1024, 1)
                        net_out_kbps = round(tx_delta / elapsed / 1024, 1)
                _prev_net_mcp = {"bytes_sent": bytes_sent, "bytes_recv": bytes_recv, "ts": now_ts}

            data = {
                "cpu_percent": cpu_data.get("cpu_percent_snapshot", 0.0),
                "load_avg": load_data.get("load_avg", [0.0, 0.0, 0.0]),
                "memory_percent": mem_data.get("percent", 0.0),
                "disk_percent": disk_pct,
                "net_in_kbps": net_in_kbps,
                "net_out_kbps": net_out_kbps,
                "timestamp": datetime.now().isoformat(),
                "mcp_connected": mcp_ok,
            }
            yield f"data: {json.dumps(data)}\n\n"
        except Exception as e:
            logger.error(f"[Monitor] MCP 获取指标失败: {e}")
            yield f"data: {json.dumps({'error': '监控数据采集失败', 'mcp_connected': False})}\n\n"
        await asyncio.sleep(3)


@router.get("/monitor/metrics")
async def get_metrics(
    auth: AuthContext = Depends(require_auth(AuthLevel.READ)),
) -> dict:
    """系统指标 REST 快照 —— 嵌套结构，无 code/data 包装"""
    return _collect_nested_metrics()


@router.get("/monitor/history")
async def get_metrics_history(
    auth: AuthContext = Depends(require_auth(AuthLevel.READ)),
    from_ts: float | None = Query(None, description="开始时间戳（Unix秒），默认5分钟前"),
    to_ts: float | None = Query(None, description="结束时间戳（Unix秒），默认当前时间"),
    metrics: str | None = Query(None, description="逗号分隔的指标名: cpu,memory,disk,network,all"),
):
    """历史指标数据 —— 通过 MCP 拉取 mcp-server 本地 SQLite 缓存"""
    client = MCPClient()
    args = {}
    if from_ts is not None:
        args["from_ts"] = from_ts
    if to_ts is not None:
        args["to_ts"] = to_ts
    if metrics is not None:
        args["metrics"] = metrics

    result = await client.call_tool("metrics_history", args)
    if result.get("ok"):
        return result["result"]
    return {"error": result.get("error", "获取历史数据失败"), "data": []}


@router.get("/monitor/stream")
async def monitor_stream():
    """SSE 实时流 —— 扁平结构，每 3 秒推送一次（通过 MCP 远程采集）"""

    async def _generator():
        async for event in _mcp_metrics_generator():
            yield event

    return StreamingResponse(
        _generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        },
    )