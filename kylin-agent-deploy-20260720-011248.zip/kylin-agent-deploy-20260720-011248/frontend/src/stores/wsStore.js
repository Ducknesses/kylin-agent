import { defineStore } from 'pinia'
import { ref } from 'vue'

// 自动适配：生产环境走 Nginx 代理（同源），开发环境直连 localhost:8000
export function getDefaultWsUrl() {
  if (import.meta.env.VITE_WS_BASE_URL) return import.meta.env.VITE_WS_BASE_URL
  // 开发环境：直连后端（Vite 未代理 /ws）
  if (import.meta.env.DEV) return 'ws://localhost:8000'
  // 生产环境：使用当前页面的 host + 协议（Nginx 已代理 /ws 路径）
  if (typeof window !== 'undefined') {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:'
    return `${protocol}//${window.location.host}`
  }
  return 'ws://localhost:8000'
}

export function getDefaultApiUrl() {
  if (import.meta.env.VITE_API_BASE_URL) return import.meta.env.VITE_API_BASE_URL
  // 开发环境：直连后端
  if (import.meta.env.DEV) return 'http://localhost:8000'
  // 生产环境：使用当前页面的协议 + host（Nginx 已代理 /api）
  if (typeof window !== 'undefined') {
    const protocol = window.location.protocol || 'http:'
    return `${protocol}//${window.location.host}`
  }
  return 'http://localhost:8000'
}

const DEFAULT_WS_URL = getDefaultWsUrl()
const DEFAULT_API_URL = getDefaultApiUrl()

export const useWsStore = defineStore('ws', () => {
  // 连接状态
  const isConnected = ref(false)
  // 重连次数
  const reconnectCount = ref(0)
  // 当前连接的 sessionId
  const activeSessionId = ref('')
  // Token 认证
  const token = ref(localStorage.getItem('api_token') || '')
  // WebSocket 连接地址（localStorage 优先，环境变量兜底）
  const wsBaseUrl = ref(localStorage.getItem('ws_base_url') || DEFAULT_WS_URL)
  // HTTP API 地址
  const apiBaseUrl = ref(localStorage.getItem('api_base_url') || DEFAULT_API_URL)
  // 是否因认证失败导致断连
  const authError = ref(false)
  // 是否因连接被拒/超时导致断连
  const connectionRefused = ref(false)
  // 当前是否正在处理后端任务（显示转圈效果）
  const processing = ref(false)
  // 当前处理状态文案
  const processingText = ref('')

  function setConnected(val) {
    isConnected.value = val
    if (val) {
      // 连接成功后清除错误标记
      authError.value = false
      connectionRefused.value = false
    }
  }

  function setReconnectCount(val) {
    reconnectCount.value = val
  }

  function setActiveSessionId(id) {
    activeSessionId.value = id
  }

  function setToken(val) {
    token.value = val
    localStorage.setItem('api_token', val)
  }

  function clearToken() {
    token.value = ''
    localStorage.removeItem('api_token')
  }

  function setWsBaseUrl(val) {
    wsBaseUrl.value = val
    localStorage.setItem('ws_base_url', val)
  }

  function setApiBaseUrl(val) {
    apiBaseUrl.value = val
    localStorage.setItem('api_base_url', val)
  }

  function setAuthError(val) {
    authError.value = val
  }

  function setConnectionRefused(val) {
    connectionRefused.value = val
  }

  /** 重置所有配置到默认值 */
  function resetToDefaults() {
    setWsBaseUrl(DEFAULT_WS_URL)
    setApiBaseUrl(DEFAULT_API_URL)
    clearToken()
  }

  return {
    isConnected,
    reconnectCount,
    activeSessionId,
    token,
    wsBaseUrl,
    apiBaseUrl,
    authError,
    connectionRefused,
    processing,
    processingText,
    setConnected,
    setReconnectCount,
    setActiveSessionId,
    setToken,
    clearToken,
    setWsBaseUrl,
    setApiBaseUrl,
    setAuthError,
    setConnectionRefused,
    resetToDefaults
  }
})
